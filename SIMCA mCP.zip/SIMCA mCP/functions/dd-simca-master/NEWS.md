v. 1.2
========
* Separate Extreme plots for New and Test datasets

v. 1.1
========
* Calculation of type II error Beta, score and orthogonal distances as well as other algorithms optimized to improve the performance on large data sets
* Unix support added
* Minor GUI fixes

v. 1.0
========
* First version released